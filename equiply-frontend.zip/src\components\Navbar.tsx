'use client';

import Link from 'next/link';

import { useState } from 'react';

import { Menu, X } from 'lucide-react';

export function Navbar() { const [open, setOpen] = useState(false);
 return <header style={{ background: 'rgba(245,246,242,.94)', borderBottom: '1px solid #e3e8e3', position: 'sticky', top: 0, zIndex: 40 }}><nav className="wrap" style={{ height: 76, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}><Link href="/" style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 900, fontSize: 22 }}><span style={{ width: 34, height: 34, background: '#236b51', color: '#fff', borderRadius: 12, display: 'grid', placeItems: 'center' }}>E</span>Equiply</Link><div style={{ display: 'flex', gap: 25, alignItems: 'center' }} className="desktop"><Link href="/equipment">Equipment</Link><Link href="/about">About</Link><Link href="/favorites">Favorites</Link><Link href="/dashboard">Dashboard</Link><Link href="/my-rentals">My rentals</Link><Link href="/profile">Profile</Link><Link href="/owner/listings">My listings</Link><Link href="/help">Help</Link><Link href="/owner">Owner</Link><Link href="/admin">Admin</Link><Link href="/login">Login</Link><Link className="btn" href="/register">Get started</Link></div><button className="mobile" onClick={() => setOpen(!open)} aria-label="Menu">{open ? <X /> : <Menu />}</button></nav>{open && <div className="wrap" style={{ paddingBottom: 20, display: 'grid', gap: 15 }}><Link href="/equipment">Equipment</Link><Link href="/about">About</Link><Link href="/favorites">Favorites</Link><Link href="/dashboard">Dashboard</Link><Link href="/my-rentals">My rentals</Link><Link href="/profile">Profile</Link><Link href="/owner/listings">My listings</Link><Link href="/help">Help</Link><Link href="/owner">Owner</Link><Link href="/admin">Admin</Link><Link href="/login">Login</Link><Link href="/register">Get started</Link></div>}<style jsx>{`.desktop{display:flex}.mobile{display:none}@media(max-width:700px){.desktop{display:none}.mobile{display:block}}`}</style></header>;
 }
